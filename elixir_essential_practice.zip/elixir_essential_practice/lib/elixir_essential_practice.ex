defmodule ElixirEssentialPractice do
  @moduledoc """
  Documentation for `ElixirEssentialPractice`.
  """

  @doc """
  Hello world.

  ## Examples

      iex> ElixirEssentialPractice.hello()
      :world

  """
  def hello do
    :world
  end
end
